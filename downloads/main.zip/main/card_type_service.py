from django.utils import timezone

from .models import CardAssignment, PoliceVerification


def resolve_card_type(person):
    if person.person_type == "night":
        return "night"

    if person.person_type == "temporary":
        return "white"

    if person.person_type == "mes_labour":
        return "pink"

    verification = PoliceVerification.objects.filter(person=person).first()

    police_valid = (
        verification is not None
        and verification.valid_until is not None
        and verification.valid_until >= timezone.localdate()
    )

    if not police_valid:
        return "white"

    if person.person_type == "permanent":
        return "yellow"

    if person.person_type == "mes_contractor":
        return "sky_blue"

    if person.person_type == "mes_supervisor":
        return "pink"

    return "white"


def sync_person_card_type(person):
    assignment = (
        CardAssignment.objects.filter(person=person, active=True)
        .select_related("card")
        .order_by("-issued_at")
        .first()
    )

    if assignment is None:
        return None

    card = assignment.card
    new_card_type = resolve_card_type(person)

    if card.card_type != new_card_type:
        card.card_type = new_card_type
        card.save(update_fields=["card_type"])

    return new_card_type