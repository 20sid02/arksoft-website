from django.urls import path
from . import views_webapp as views

urlpatterns = [
    path('', views.index, name='home'),
    path('scanner/', views.scanner_view),
    path('dashboard/', views.dashboard, name="dashboard"),
path('dashboard/cards/', views.cards_view, name="cards_view"),
path('dashboard/people/', views.people_view, name="people_view"),
path('dashboard/assignments/', views.assignments_page, name="assignments_page"),
path('dashboard/reports/', views.reports_page, name="reports_page"),
path('dashboard/guards/create/', views.create_guard_page),

path("dashboard/cards/create/", views.card_form, name="create_card"),

path("dashboard/cards/<int:card_id>/", views.card_detail_page, name="card_detail_page"),
path("dashboard/cards/<int:card_id>/renew/", views.renew_card_page, name="renew_card_page"),
path("dashboard/cards/<int:card_id>/blacklist/", views.blacklist_card_page, name="blacklist_card_page"),
path("dashboard/cards/<int:card_id>/unblacklist/", views.unblacklist_card_page, name="unblacklist_card_page"),
path("dashboard/cards/<int:card_id>/unflag/", views.unflag_card_web, name="unflag_card_web"
),
path("dashboard/people/<int:person_id>/", views.person_detail_page, name="person_detail_page"),
path("dashboard/people/<int:person_id>/edit/", views.edit_person_page, name="edit_person_page"),

path("dashboard/guards/", views.guards_page, name="guards_page"),
path("dashboard/guards/<int:guard_id>/", views.guard_detail_page, name="guard_detail_page"),
path("dashboard/guards/<int:guard_id>/edit/", views.edit_guard_page, name="edit_guard_page"),
path("dashboard/guards/<int:guard_id>/approve/", views.approve_guard_page, name="approve_guard_page"),
path("dashboard/guards/<int:guard_id>/unapprove/", views.unapprove_guard_page, name="unapprove_guard_page"),
path("dashboard/guards/<int:guard_id>/activate/", views.activate_guard_page, name="activate_guard_page"),
path("dashboard/guards/<int:guard_id>/deactivate/", views.deactivate_guard_page, name="deactivate_guard_page"),

path("dashboard/cards/<int:card_id>/print/", views.print_card_page, name="print_card_page"),
path(
    "dashboard/cards/<int:card_id>/delete/",
    views.delete_card_page,
    name="delete_card_page",
),
path(
    "dashboard/people/<int:person_id>/hide/",
    views.hide_person_page,
    name="hide_person_page",
),

path(
    "dashboard/people/<int:person_id>/unhide/",
    views.unhide_person_page,
    name="unhide_person_page",
),
path(
    "dashboard/cards/<int:card_id>/signature/",
    views.update_card_signature_page,
    name="update_card_signature_page",
),

]
