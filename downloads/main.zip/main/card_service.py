import os
import qrcode
from django.conf import settings
from django.utils import timezone
from datetime import timedelta

from .models import Person, Card, CardAssignment


def create_card_logic(name, contact, aadhaar, validity_option, valid_until):
    if not all([name, contact, aadhaar, validity_option]):
        return {"error": "Missing fields"}

    # Create person
    person = Person.objects.create(
        name=name,
        contact=contact,
        aadhaar_num=aadhaar
    )

    # Create card
    card = Card.objects.create(status="VA")

    # Handle validity
    now = timezone.now()

    if validity_option == "24h":
        valid_until = now + timedelta(hours=24)
    elif validity_option == "1w":
        valid_until = now + timedelta(weeks=1)
    elif validity_option == "1m":
        valid_until = now + timedelta(days=30)
    elif validity_option == "3m":
        valid_until = now + timedelta(days=90)
    elif validity_option == "6m":
        valid_until = now + timedelta(days=180)
    elif validity_option == "1y":
        valid_until = now + timedelta(days=365)
    elif validity_option == "custom":
        if not valid_until:
            return {"error": "Custom date required"}
    else:
        return {"error": "Invalid validity option"}

    # Create assignment
    CardAssignment.objects.create(
        person=person,
        card=card,
        issued_at=now,
        valid_until=valid_until,
        active=True
    )

    # Generate QR
    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=1,
    )
    qr.add_data(str(card.card_id))
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")

    qr_folder = os.path.join(settings.MEDIA_ROOT, "qr_codes")
    os.makedirs(qr_folder, exist_ok=True)

    qr_path = os.path.join(qr_folder, f"{card.card_id}.png")
    img.save(qr_path)

    return {
        "status": "card_created",
        "user_id": person.user_id,
        "card_id": card.card_id,
        "qr_code": f"{settings.MEDIA_URL}qr_codes/{card.card_id}.png",
    }