import os
import csv
import io
import requests
from datetime import datetime, timedelta
import base64

from django.core.files.base import ContentFile
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Q, CharField, OuterRef, Subquery
from django.db.models.functions import Cast
from django.contrib import messages
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.cache import never_cache

from .decorators import admin_required, admin_or_demo_required
from .models import (
    AccessLog,
    Card,
    CardAssignment,
    Guard,
    Person,
    PoliceVerification,
)
from .card_type_service import sync_person_card_type
from .decorators import admin_required
from .card_service import create_card_logic


def _is_demo_user(user):
    try:
        return user.guard.role == "demo"
    except Exception:
        return False


def _get_display_status(card, assignment):
    if card.status == "BL":
        return "BLACKLISTED"
    if card.status == "FL":
        return "FLAGGED"
    if card.status == "IV":
        return "INVALID"
    if not assignment:
        return "NO ASSIGNMENT"
    if not assignment.active:
        return "INACTIVE"
    if assignment.valid_until < timezone.now():
        return "EXPIRED"
    if card.status == "VA":
        return "ACTIVE"
    return "UNKNOWN"

def _get_card_type_display(card):
    mapping = {
        "yellow": "Permanent (Yellow)",
        "white": "Temporary (White)",
        "pink": "MES Labour / Supervisor (Pink)",
        "sky_blue": "MES Contractor (Sky Blue)",
        "night": "Night Pass",
    }

    return mapping.get(card.card_type, "Unknown")

def _resolve_card_type_for_web(person_type, police_valid_until):
    if person_type == "night":
        return "night"

    if person_type == "temporary":
        return "white"

    today = timezone.localdate()
    police_valid = police_valid_until and police_valid_until >= today

    if not police_valid:
        return "white"

    if person_type == "permanent":
        return "yellow"

    if person_type == "mes_contractor":
        return "pink"

    if person_type in ["mes_labour", "mes_supervisor"]:
        return "pink"

    return "white"

def _resolve_valid_until(validity_option, custom_date):
    now = timezone.now()

    if validity_option == "24h":
        return now + timedelta(hours=24)
    if validity_option == "1w":
        return now + timedelta(weeks=1)
    if validity_option == "1m":
        return now + timedelta(days=30)
    if validity_option == "3m":
        return now + timedelta(days=90)
    if validity_option == "6m":
        return now + timedelta(days=180)
    if validity_option == "1y":
        return now + timedelta(days=365)
    if validity_option == "custom" and custom_date:
        valid_until = datetime.strptime(custom_date, "%Y-%m-%d")
        valid_until = valid_until.replace(hour=23, minute=59, second=59)
        return timezone.make_aware(valid_until)

    return None

def _get_person_type_display(person_type):
    mapping = {
        "temporary": "Temporary",
        "permanent": "Permanent",
        "mes_contractor": "MES Contractor",
        "mes_labour": "MES Labour",
        "mes_supervisor": "MES Supervisor",
        "night": "Night Pass",
    }

    return mapping.get(person_type, "-")

@login_required
@admin_required
def card_form(request):
    result = None

    if request.method == "POST":
        api_url = request.build_absolute_uri("/api/create-card/")

        uploaded_signature = request.FILES.get(
            "approval_signature"
        )

        files = None

        if uploaded_signature:
            files = {
                "approval_signature": (
                    uploaded_signature.name,
                    uploaded_signature.file,
                    uploaded_signature.content_type,
                )
            }

        try:
            response = requests.post(
                api_url,
                data=request.POST.dict(),
                files=files,
                cookies=request.COOKIES,
                headers={
                    "X-CSRFToken": request.COOKIES.get(
                        "csrftoken",
                        "",
                    )
                },
                timeout=20,
            )

            try:
                result = response.json()
            except ValueError:
                result = {
                    "error": (
                        "Card creation API returned a non-JSON "
                        f"response with status {response.status_code}"
                    )
                }

        except requests.exceptions.Timeout:
            result = {
                "error": "Card creation request timed out."
            }

        except requests.exceptions.RequestException as error:
            result = {
                "error": (
                    "Could not connect to card creation API: "
                    f"{str(error)}"
                )
            }

        except Exception as error:
            result = {
                "error": (
                    "Unexpected error while creating card: "
                    f"{str(error)}"
                )
            }

    return render(
        request,
        "card_form.html",
        {
            "result": result,
        },
    )


@never_cache
@login_required
def scanner_view(request):
    try:
        guard = request.user.guard_profile
    except Exception:
        return redirect("/")

    if not guard.approved or not guard.active:
        return redirect("/")

    return render(request, "scanner.html")


def index(request):
    return render(request, "index.html")


def custom_logout(request):
    logout(request)
    return redirect("/")


@login_required
@admin_or_demo_required
def dashboard(request):
    search_query = request.GET.get("q", "").strip()
    access_type = request.GET.get("access_type", "").strip()
    gate_query = request.GET.get("gate", "").strip()

    logs = (
        AccessLog.objects
        .select_related("card", "gate", "scanned_by")
        .prefetch_related(
            "card__cardassignment_set__person",
            "gate__gateinfo_set",
        )
        .order_by("-timestamp")
    )

    if access_type in ["IN", "OUT", "DENIED"]:
        logs = logs.filter(access_type=access_type)
    else:
        access_type = ""

    if gate_query:
        logs = logs.filter(
            Q(gate__gate_id__icontains=gate_query)
            | Q(gate__gateinfo__name__icontains=gate_query)
        ).distinct()

    if search_query:
        logs = logs.filter(
            Q(card__card_id__icontains=search_query)
            | Q(card__cardassignment__person__name__icontains=search_query)
            | Q(card__cardassignment__person__aadhaar_num__icontains=search_query)
            | Q(card__cardassignment__person__contact__icontains=search_query)
            | Q(scanned_by__full_name__icontains=search_query)
            | Q(scanned_by__employee_id__icontains=search_query)
            | Q(gate__gateinfo__name__icontains=search_query)
        ).distinct()

    result_count = logs.count()

    allowed_page_sizes = {10, 25, 50, 100}

    try:
        page_size = int(request.GET.get("page_size", 10))
    except (TypeError, ValueError):
        page_size = 10

    if page_size not in allowed_page_sizes:
        page_size = 10

    paginator = Paginator(logs, page_size)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    log_rows = []

    for log in page_obj.object_list:
        assignment = (
            log.card.cardassignment_set
            .select_related("person")
            .order_by("-issued_at")
            .first()
        )

        gate_info = log.gate.gateinfo_set.first()

        log_rows.append(
            {
                "card_id": log.card.card_id,
                "person": (
                    assignment.person.name
                    if assignment and assignment.person
                    else "Unknown"
                ),
                "person_id": (
                    assignment.person.user_id
                    if assignment and assignment.person
                    else None
                ),
                "gate_name": (
                    gate_info.name
                    if gate_info
                    else f"Gate {log.gate.gate_id}"
                ),
                "access_type": log.access_type,
                "scanned_by": (
                    log.scanned_by.full_name
                    if log.scanned_by
                    else "Unknown"
                ),
                "timestamp": log.timestamp,
            }
        )

    query_params = request.GET.copy()
    query_params.pop("page", None)

    return render(
        request,
        "dashboard.html",
        {
            "logs": log_rows,
            "page_obj": page_obj,
            "paginator": paginator,
            "result_count": result_count,
            "search_query": search_query,
            "selected_access_type": access_type,
            "gate_query": gate_query,
            "selected_page_size": page_size,
            "pagination_query": query_params.urlencode(),
        },
    )

@never_cache
@login_required
@admin_or_demo_required
def cards_view(request):
    search_query = request.GET.get("q", "").strip()
    selected_status = request.GET.get("status", "").strip()
    selected_card_type = request.GET.get("card_type", "").strip()
    selected_person_type = request.GET.get("person_type", "").strip()
    selected_visibility = request.GET.get(
        "visibility",
        "visible",
    ).strip()

    latest_assignment_queryset = (
        CardAssignment.objects
        .filter(card=OuterRef("pk"))
        .select_related("person")
        .order_by("-issued_at")
    )

    cards = (
        Card.objects
        .annotate(
            card_id_text=Cast(
                "card_id",
                output_field=CharField(),
            ),
            latest_assignment_id=Subquery(
                latest_assignment_queryset.values("id")[:1]
            ),
            latest_assignment_active=Subquery(
                latest_assignment_queryset.values("active")[:1]
            ),
            latest_assignment_valid_until=Subquery(
                latest_assignment_queryset.values(
                    "valid_until"
                )[:1]
            ),
            latest_person_id=Subquery(
                latest_assignment_queryset.values(
                    "person__user_id"
                )[:1]
            ),
            latest_person_name=Subquery(
                latest_assignment_queryset.values(
                    "person__name"
                )[:1]
            ),
            latest_person_type=Subquery(
                latest_assignment_queryset.values(
                    "person__person_type"
                )[:1]
            ),
            latest_person_aadhaar=Subquery(
                latest_assignment_queryset.values(
                    "person__aadhaar_num"
                )[:1]
            ),
            latest_person_contact=Subquery(
                latest_assignment_queryset.values(
                    "person__contact"
                )[:1]
            ),
            latest_person_occupation=Subquery(
                latest_assignment_queryset.values(
                    "person__occupation"
                )[:1]
            ),
        )
    )

    # Visibility filter
    if selected_visibility == "hidden":
        cards = cards.filter(is_hidden=True)

    elif selected_visibility == "all":
        pass

    else:
        selected_visibility = "visible"
        cards = cards.filter(is_hidden=False)

    allowed_person_types = {
        "temporary",
        "permanent",
        "mes_contractor",
        "mes_labour",
        "mes_supervisor",
        "night",
    }

    if selected_person_type in allowed_person_types:
        cards = cards.filter(
            latest_person_type=selected_person_type
        )
    else:
        selected_person_type = ""

    # Card colour/type filter
    allowed_card_types = {
        "yellow",
        "white",
        "pink",
        "sky_blue",
        "night",
    }

    if selected_card_type in allowed_card_types:
        cards = cards.filter(
            card_type=selected_card_type
        )
    else:
        selected_card_type = ""

    # Search
    if search_query:
        cards = cards.filter(
            Q(card_id_text__icontains=search_query)
            | Q(
                latest_person_name__icontains=
                search_query
            )
            | Q(
                latest_person_aadhaar__icontains=
                search_query
            )
            | Q(
                latest_person_contact__icontains=
                search_query
            )
            | Q(
                latest_person_occupation__icontains=
                search_query
            )
        )

    now = timezone.now()

    allowed_statuses = {
        "active",
        "expired",
        "inactive",
        "unassigned",
        "flagged",
        "blacklisted",
        "invalid",
    }

    if selected_status not in allowed_statuses:
        selected_status = ""

    if selected_status == "active":
        cards = cards.filter(
            status="VA",
            latest_assignment_active=True,
            latest_assignment_valid_until__gte=now,
        )

    elif selected_status == "expired":
        cards = cards.filter(
            status="VA",
            latest_assignment_active=True,
            latest_assignment_valid_until__lt=now,
        )

    elif selected_status == "inactive":
        cards = cards.filter(
            status="VA",
            latest_assignment_active=False,
        )

    elif selected_status == "unassigned":
        cards = cards.filter(
            latest_assignment_id__isnull=True
        )

    elif selected_status == "flagged":
        cards = cards.filter(status="FL")

    elif selected_status == "blacklisted":
        cards = cards.filter(status="BL")

    elif selected_status == "invalid":
        cards = cards.filter(status="IV")

    cards = cards.order_by("-card_id")

    # Pagination
    allowed_page_sizes = {10, 25, 50, 100}

    try:
        page_size = int(
            request.GET.get("page_size", 10)
        )
    except (TypeError, ValueError):
        page_size = 10

    if page_size not in allowed_page_sizes:
        page_size = 10

    paginator = Paginator(cards, page_size)

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    card_rows = []

    for card in page_obj.object_list:
        if card.status == "BL":
            display_status = "BLACKLISTED"

        elif card.status == "FL":
            display_status = "FLAGGED"

        elif card.status == "IV":
            display_status = "INVALID"

        elif card.latest_assignment_id is None:
            display_status = "UNASSIGNED"

        elif not card.latest_assignment_active:
            display_status = "INACTIVE"

        elif (
            card.latest_assignment_valid_until
            and
            card.latest_assignment_valid_until < now
        ):
            display_status = "EXPIRED"

        elif card.status == "VA":
            display_status = "ACTIVE"

        else:
            display_status = "UNKNOWN"

        card_rows.append({
            "card_id": card.card_id,
            "raw_status": card.status,
            "display_status": display_status,
            "card_type": card.card_type,
            "card_type_display": (
                card.get_card_type_display()
            ),
            "person_name": (
                card.latest_person_name
                or "Unassigned"
            ),
            "person_type": card.latest_person_type,
            "person_type_display": _get_person_type_display(
                card.latest_person_type
            ),
            "person_id": card.latest_person_id,
            "valid_until": (
                card.latest_assignment_valid_until
            ),
            "assignment_active": (
                card.latest_assignment_active
                if card.latest_assignment_id
                else False
            ),
            "is_hidden": card.is_hidden,
        })

    query_params = request.GET.copy()
    query_params.pop("page", None)

    return render(
        request,
        "cards.html",
        {
            "cards": card_rows,
            "page_obj": page_obj,
            "paginator": paginator,
            "result_count": paginator.count,
            "search_query": search_query,
            "selected_status": selected_status,
            "selected_person_type": selected_person_type,
            "selected_card_type": selected_card_type,
            "selected_visibility": (
                selected_visibility
            ),
            "selected_page_size": page_size,
            "pagination_query": (
                query_params.urlencode()
            ),
        },
    )

@never_cache
@login_required
@admin_required
def delete_card_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    if request.method != "POST":
        return redirect("card_detail_page", card_id=card.card_id)

    card.status = "IV"
    card.is_hidden = True
    card.hidden_at = timezone.now()
    card.save(update_fields=["status", "is_hidden", "hidden_at"])

    assigned_person_ids = list(
        CardAssignment.objects.filter(card=card)
        .values_list("person_id", flat=True)
        .distinct()
    )

    for person_id in assigned_person_ids:
        person = Person.objects.get(user_id=person_id)

        has_another_active_card = (
            CardAssignment.objects
            .filter(
                person=person,
                active=True,
                card__is_hidden=False,
            )
            .exists()
        )

        if not has_another_active_card:
            person.is_hidden = True
            person.hidden_at = timezone.now()
            person.save(
                update_fields=[
                    "is_hidden",
                    "hidden_at",
                ]
            )

    CardAssignment.objects.filter(
        card=card,
        active=True,
    ).update(active=False)

    return redirect("cards_view")

@never_cache
@login_required
@admin_or_demo_required
def people_view(request):
    search_query = request.GET.get("q", "").strip()
    person_type = request.GET.get("person_type", "").strip()
    visibility = request.GET.get("visibility", "active").strip()

    people = Person.objects.all()

    # Visibility filter
    if visibility == "hidden":
        people = people.filter(is_hidden=True)
    elif visibility == "all":
        pass
    else:
        visibility = "active"
        people = people.filter(is_hidden=False)

    # MES/person classification filter
    allowed_person_types = {
        "temporary",
        "permanent",
        "mes_contractor",
        "mes_labour",
        "mes_supervisor",
        "night",
    }

    if person_type in allowed_person_types:
        people = people.filter(person_type=person_type)
    else:
        person_type = ""

    # Search
    if search_query:
        search_filter = (
            Q(name__icontains=search_query)
            | Q(contact__icontains=search_query)
            | Q(aadhaar_num__icontains=search_query)
            | Q(occupation__icontains=search_query)
            | Q(identification_mark__icontains=search_query)
            | Q(address__icontains=search_query)
            | Q(temporary_address__icontains=search_query)
            | Q(sponsor_name__icontains=search_query)
            | Q(sponsor_rank__icontains=search_query)
            | Q(sponsor_unit__icontains=search_query)
        )

        if search_query.isdigit():
            search_filter |= Q(user_id=int(search_query))

        people = people.filter(search_filter)

    people = people.order_by("name", "user_id")

    result_count = people.count()

    allowed_page_sizes = {10, 25, 50, 100}

    try:
        page_size = int(request.GET.get("page_size", 10))
    except (TypeError, ValueError):
        page_size = 10

    if page_size not in allowed_page_sizes:
        page_size = 10

    paginator = Paginator(people, page_size)

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    query_params = request.GET.copy()
    query_params.pop("page", None)

    return render(
        request,
        "people.html",
        {
            "people": page_obj,
            "page_obj": page_obj,
            "paginator": paginator,
            "search_query": search_query,
            "selected_person_type": person_type,
            "selected_visibility": visibility,
            "selected_page_size": page_size,
            "result_count": result_count,
            "pagination_query": query_params.urlencode(),
        },
    )

@never_cache
@login_required
@admin_required
def edit_person_page(request, person_id):
    person = get_object_or_404(Person, user_id=person_id)

    police_verification = getattr(
        person,
        "police_verification",
        None,
    )

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        contact = request.POST.get("contact", "").strip()
        aadhaar_num = request.POST.get("aadhaar_num", "").strip()

        occupation = request.POST.get("occupation", "").strip()
        identification_mark = request.POST.get("identification_mark", "").strip()
        address = request.POST.get("address", "").strip()
        # telephone_number = request.POST.get("telephone_number", "").strip()
        # quarter_number = request.POST.get("quarter_number", "").strip()
        # sector = request.POST.get("sector", "").strip()
        temporary_address = request.POST.get("temporary_address", "").strip()
        person_type = request.POST.get("person_type", "normal").strip()

        sponsor_rank = request.POST.get("sponsor_rank", "").strip()
        sponsor_name = request.POST.get("sponsor_name", "").strip()
        sponsor_unit = request.POST.get("sponsor_unit", "").strip()
        security_deposit_amount = request.POST.get("security_deposit_amount", "0").strip() or "0"

        police_station = request.POST.get("police_station", "").strip()
        verification_number = request.POST.get("verification_number", "").strip()
        police_issue_date = request.POST.get("police_issue_date") or None
        police_valid_until = request.POST.get("police_valid_until") or None

        uploaded_photo = request.FILES.get("photo")
        photo_data = request.POST.get("photo_data", "").strip()
        remove_photo = request.POST.get("remove_photo") == "on"

        error = None

        if not name:
            error = "Name is required."
        elif not contact:
            error = "Contact is required."
        elif not aadhaar_num:
            error = "Aadhaar is required."
        elif not occupation:
            error = "Occupation is required."
        elif person_type not in [
    "temporary",
    "permanent",
    "mes_contractor",
    "mes_labour",
    "mes_supervisor",
    "night",
]:
            error = "Invalid person classification."

        if error:
            return render(
                request,
                "edit_person.html",
                {
                    "person": person,
                    "police_verification": police_verification,
                    "error": error,
                },
            )

        person.name = name
        person.contact = contact
        person.aadhaar_num = aadhaar_num
        person.occupation = occupation
        person.identification_mark = identification_mark
        person.address = address
        # person.telephone_number = telephone_number
        # person.quarter_number = quarter_number
        # person.sector = sector
        person.temporary_address = temporary_address
        person.person_type = person_type
        person.sponsor_rank = sponsor_rank
        person.sponsor_name = sponsor_name
        person.sponsor_unit = sponsor_unit
        person.security_deposit_amount = security_deposit_amount

        if remove_photo:
            if person.photo:
                person.photo.delete(save=False)
            person.photo = None

        elif uploaded_photo:
            if person.photo:
                person.photo.delete(save=False)

            person.photo = uploaded_photo

        elif photo_data:
            try:
                if ";base64," not in photo_data:
                    raise ValueError("Invalid captured-photo format")

                format_part, encoded_image = photo_data.split(";base64,", 1)
                extension = format_part.split("/")[-1]

                if extension == "jpeg":
                    extension = "jpg"

                photo_file = ContentFile(
                    base64.b64decode(encoded_image),
                    name=f"person_{person.user_id}.{extension}",
                )

                if person.photo:
                    person.photo.delete(save=False)

                person.photo = photo_file

            except (ValueError, TypeError, base64.binascii.Error):
                return render(
                    request,
                    "edit_person.html",
                    {
                        "person": person,
                        "police_verification": police_verification,
                        "error": "The captured photo could not be processed.",
                    },
                )

        person.save()

        police_fields_supplied = any(
            [
                police_station,
                verification_number,
                police_issue_date,
                police_valid_until,
            ]
        )

        if police_fields_supplied:
            verification, _ = PoliceVerification.objects.get_or_create(
                person=person
            )
        
            if police_station:
                verification.police_station = police_station
        
            if verification_number:
                verification.verification_number = verification_number
        
            if police_issue_date:
                verification.issue_date = police_issue_date

            if police_valid_until:
                verification.valid_until = police_valid_until

            verification.save()

        sync_person_card_type(person)
        return redirect("person_detail_page", person_id=person.user_id)

    return render(
        request,
        "edit_person.html",
        {
            "person": person,
            "police_verification": police_verification,
        },
    )


@login_required
@admin_required
@transaction.atomic
def hide_person_page(request, person_id):
    person = get_object_or_404(Person, user_id=person_id)

    if request.method != "POST":
        return redirect(
            "person_detail_page",
            person_id=person.user_id,
        )

    active_assignments = (
        CardAssignment.objects
        .filter(
            person=person,
            active=True,
        )
        .select_related("card")
    )

    for assignment in active_assignments:
        assignment.active = False
        assignment.save(update_fields=["active"])

        card = assignment.card
        card.status = "IV"
        card.is_hidden = True
        card.hidden_at = timezone.now()
        card.save(
            update_fields=[
                "status",
                "is_hidden",
                "hidden_at",
            ]
        )

    person.is_hidden = True
    person.hidden_at = timezone.now()
    person.save(
        update_fields=[
            "is_hidden",
            "hidden_at",
        ]
    )

    return redirect("people_view")


@never_cache
@login_required
@admin_required
def unhide_person_page(request, person_id):
    person = get_object_or_404(Person, user_id=person_id)

    if request.method != "POST":
        return redirect(
            "person_detail_page",
            person_id=person.user_id,
        )

    person.is_hidden = False
    person.hidden_at = None
    person.save(
        update_fields=[
            "is_hidden",
            "hidden_at",
        ]
    )

    return redirect(
        "person_detail_page",
        person_id=person.user_id,
    )

@never_cache
@login_required
@admin_required
def assignments_page(request):
    assignments = (
        CardAssignment.objects.select_related("person", "card")
        .order_by("-issued_at")
    )

    assignment_rows = []

    for item in assignments:
        assignment_rows.append(
            {
                "person_id": item.person.user_id,
                "person_name": item.person.name,
                "card_id": item.card.card_id,
                "issued_at": item.issued_at,
                "valid_until": item.valid_until,
                "active": item.active,
                "display_status": _get_display_status(item.card, item),
            }
        )

    return render(
        request,
        "assignments.html",
        {
            "assignments": assignment_rows,
            "is_demo": _is_demo_user(request.user),
        },
    )


@login_required
@admin_required
def guards_page(request):
    guards = Guard.objects.select_related("user").order_by("-created_at")
    guard_rows = []

    for guard in guards:
        guard_rows.append(
            {
                "id": guard.id,
                "full_name": guard.full_name,
                "username": guard.user.username,
                "employee_id": guard.employee_id,
                "contact": guard.contact,
                "role": guard.role,
                "approved": guard.approved,
                "active": guard.active,
                "created_at": guard.created_at,
            }
        )

    return render(
        request,
        "guards.html",
        {
            "guards": guard_rows,
            "is_demo": False,
        },
    )


@login_required
@admin_required
def guard_detail_page(request, guard_id):
    guard = get_object_or_404(Guard.objects.select_related("user"), id=guard_id)

    return render(
        request,
        "guard_detail.html",
        {
            "guard": guard,
            "is_demo": False,
        },
    )


@never_cache
@login_required
@admin_required
def create_guard_page(request):
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()
        full_name = request.POST.get("full_name", "").strip()
        employee_id = request.POST.get("employee_id", "").strip()
        contact = request.POST.get("contact", "").strip()
        role = request.POST.get("role", "guard").strip()
        approved = request.POST.get("approved") == "on"
        active = request.POST.get("active") == "on"

        error = None

        if not username:
            error = "Username is required."
        elif not password:
            error = "Password is required."
        elif not full_name:
            error = "Full name is required."
        elif not employee_id:
            error = "Employee ID is required."
        elif role not in ["admin", "guard", "demo"]:
            error = "Invalid role."
        elif User.objects.filter(username=username).exists():
            error = "Username already exists."
        elif Guard.objects.filter(employee_id=employee_id).exists():
            error = "Employee ID already exists."

        if error:
            return render(
                request,
                "create_guard.html",
                {
                    "error": error,
                    "form_data": {
                        "username": username,
                        "full_name": full_name,
                        "employee_id": employee_id,
                        "contact": contact,
                        "role": role,
                        "approved": approved,
                        "active": active,
                    },
                    "is_demo": False,
                },
            )

        user = User.objects.create_user(
            username=username,
            password=password,
            is_active=True,
        )

        guard = Guard.objects.create(
            user=user,
            full_name=full_name,
            employee_id=employee_id,
            contact=contact,
            role=role,
            approved=approved,
            active=active,
        )

        return redirect("guard_detail_page", guard_id=guard.id)

    return render(
        request,
        "create_guard.html",
        {
            "is_demo": False,
        },
    )


@never_cache
@login_required
@admin_required
def edit_guard_page(request, guard_id):
    guard = get_object_or_404(Guard.objects.select_related("user"), id=guard_id)

    if request.method == "POST":
        full_name = request.POST.get("full_name", "").strip()
        employee_id = request.POST.get("employee_id", "").strip()
        contact = request.POST.get("contact", "").strip()
        role = request.POST.get("role", "guard").strip()
        username = request.POST.get("username", "").strip()

        error = None

        if not full_name:
            error = "Full name is required."
        elif not employee_id:
            error = "Employee ID is required."
        elif not username:
            error = "Username is required."
        elif role not in ["admin", "guard"]:
            error = "Invalid role."
        elif Guard.objects.exclude(id=guard.id).filter(employee_id=employee_id).exists():
            error = "Employee ID already exists."
        elif User.objects.exclude(id=guard.user.id).filter(username=username).exists():
            error = "Username already exists."

        if error:
            return render(
                request,
                "edit_guard.html",
                {
                    "guard": guard,
                    "error": error,
                    "is_demo": False,
                },
            )

        guard.full_name = full_name
        guard.employee_id = employee_id
        guard.contact = contact
        guard.role = role
        guard.save()

        guard.user.username = username
        guard.user.save()

        return redirect("guard_detail_page", guard_id=guard.id)

    return render(
        request,
        "edit_guard.html",
        {
            "guard": guard,
            "is_demo": False,
        },
    )


@never_cache
@login_required
@admin_required
def approve_guard_page(request, guard_id):
    guard = get_object_or_404(Guard, id=guard_id)

    if request.method == "POST":
        guard.approved = True
        guard.save(update_fields=["approved"])

    return redirect("guard_detail_page", guard_id=guard.id)


@never_cache
@login_required
@admin_required
def unapprove_guard_page(request, guard_id):
    guard = get_object_or_404(Guard, id=guard_id)

    if request.method == "POST":
        guard.approved = False
        guard.save(update_fields=["approved"])

    return redirect("guard_detail_page", guard_id=guard.id)


@never_cache
@login_required
@admin_required
def activate_guard_page(request, guard_id):
    guard = get_object_or_404(Guard, id=guard_id)

    if request.method == "POST":
        guard.active = True
        guard.save(update_fields=["active"])

    return redirect("guard_detail_page", guard_id=guard.id)


@never_cache
@login_required
@admin_required
def deactivate_guard_page(request, guard_id):
    guard = get_object_or_404(Guard, id=guard_id)

    if request.method == "POST":
        guard.active = False
        guard.save(update_fields=["active"])

    return redirect("guard_detail_page", guard_id=guard.id)


@login_required
@admin_or_demo_required
def card_detail_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    assignment = (
        CardAssignment.objects.filter(card=card)
        .select_related("person")
        .order_by("-issued_at")
        .first()
    )
    police_verification = None

    if assignment and assignment.person:
        police_verification = getattr(
            assignment.person,
            "police_verification",
            None,
        )

    qr_relative_path = f"qr_codes/{card.card_id}.png"
    qr_full_path = os.path.join(settings.MEDIA_ROOT, qr_relative_path)

    if os.path.exists(qr_full_path):
        qr_url = f"{settings.MEDIA_URL}{qr_relative_path}"

    else:
        qr_url = None

    display_status = "UNKNOWN"

    if card.status == "BL":
        display_status = "BLACKLISTED"

    elif card.status == "FL":
        display_status = "FLAGGED"

    elif card.status == "IV":
        display_status = "INVALID"

    elif assignment:

        if not assignment.active:
            display_status = "INACTIVE"

        elif assignment.valid_until < timezone.now():
            display_status = "EXPIRED"

        elif card.status == "VA":
            display_status = "ACTIVE"

    else:
        display_status = "NO ASSIGNMENT"

    return render(
        request,
        "card_detail.html",
        {
            "card": card,
            "assignment": assignment,
            "display_status": display_status,
            "qr_url": qr_url,
            "is_demo": _is_demo_user(request.user),
            "police_verification": police_verification,
            "card_type_display": _get_card_type_display(card),

        },
    )


@never_cache
@login_required
@admin_required
def renew_card_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    assignment = (
        CardAssignment.objects.filter(card=card)
        .select_related("person")
        .order_by("-issued_at")
        .first()
    )

    if not assignment:
        return redirect("card_detail_page", card_id=card.card_id)

    if request.method == "POST":
        valid_until = _resolve_valid_until(
            request.POST.get("validity_option"),
            request.POST.get("valid_until"),
        )

        if not valid_until:
            return render(
                request,
                "renew_card.html",
                {
                    "card": card,
                    "assignment": assignment,
                    "error": "Invalid validity option",
                    "is_demo": False,
                },
            )

        assignment.valid_until = valid_until
        assignment.active = True
        assignment.save(update_fields=["valid_until", "active"])

        if card.status in ["IV", "VA"]:
            card.status = "VA"
            card.save(update_fields=["status"])

        return redirect("card_detail_page", card_id=card.card_id)

    return render(
        request,
        "renew_card.html",
        {
            "card": card,
            "assignment": assignment,
            "is_demo": False,
        },
    )


@never_cache
@login_required
@admin_required
def blacklist_card_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    if request.method == "POST":
        card.status = "BL"
        card.save(update_fields=["status"])

    return redirect("card_detail_page", card_id=card.card_id)


@never_cache
@login_required
@admin_required
def unblacklist_card_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    if request.method == "POST":
        card.status = "VA"
        card.save(update_fields=["status"])

    return redirect("card_detail_page", card_id=card.card_id)


@login_required
@admin_or_demo_required
def person_detail_page(request, person_id):
    person = get_object_or_404(Person, user_id=person_id)

    police_verification = getattr(
        person,
        "police_verification",
        None,
        )

    latest_assignment = (
        CardAssignment.objects.filter(person=person)
        .select_related("card")
        .order_by("-issued_at")
        .first()
    )

    display_status = "NO CARD"

    if latest_assignment:
        display_status = _get_display_status(latest_assignment.card, latest_assignment)

    assignment_history = (
        CardAssignment.objects.filter(person=person)
        .select_related("card")
        .order_by("-issued_at")
    )

    return render(
        request,
        "person_detail.html",
        {
            "person": person,
            "latest_assignment": latest_assignment,
            "display_status": display_status,
            "assignment_history": assignment_history,
            "is_demo": _is_demo_user(request.user),
            "police_verification": police_verification,
        },
    )


@login_required
@admin_required
def print_card_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    assignment = (
        CardAssignment.objects.filter(card=card)
        .select_related("person")
        .order_by("-issued_at")
        .first()
    )

    police_verification = None

    if assignment and assignment.person:
        police_verification = getattr(
            assignment.person,
            "police_verification",
            None,
        )

    format_type = request.GET.get("format", "standard")

    # Night-pass band rendering style. Applies to the "night" card
    # category; can be overridden via ?night_style= to preview both looks.
    #   "stripes" -> black diagonal stripes on white
    #   "solid"   -> whole band turned solid black
    night_style = request.GET.get("night_style", "").strip().lower()

    if night_style not in ("stripes", "solid", "off"):
        night_style = "solid" if card.card_type == "night" else "off"

    qr_relative_path = f"qr_codes/{card.card_id}.png"
    qr_full_path = os.path.join(settings.MEDIA_ROOT, qr_relative_path)

    qr_url = None

    if os.path.exists(qr_full_path):
        qr_url = f"{settings.MEDIA_URL}{qr_relative_path}"

    template_map = {
        "standard": "print_card_standard.html",
        "minimal": "print_card_minimal.html",
        "compact": "print_card_compact.html",
        "photo": "print_card_photo.html",
    }

    template_name = template_map.get(format_type, "print_card_standard.html")

    return render(
        request,
        template_name,
        {
            "card": card,
            "assignment": assignment,
            "qr_url": qr_url,
            "format_type": format_type,
            "night_style": night_style,
            "is_demo": False,
            "card_type_display": _get_card_type_display(card),
            "police_verification": police_verification,
        },
    )


@never_cache
@login_required
@admin_required
def unflag_card_web(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    if request.method != "POST":
        return redirect("card_detail_page", card_id=card.card_id)

    if card.status == "FL":
        card.status = "VA"
        card.save(update_fields=["status"])
        messages.success(request, "Card unflagged successfully.")

    return redirect(f"/dashboard/cards/{card_id}/")

@never_cache
@login_required
@admin_required
def update_card_signature_page(request, card_id):
    card = get_object_or_404(Card, card_id=card_id)

    assignment = (
        CardAssignment.objects
        .filter(card=card)
        .select_related("person")
        .order_by("-issued_at")
        .first()
    )

    if not assignment:
        return redirect(
            "card_detail_page",
            card_id=card.card_id,
        )

    if request.method != "POST":
        return redirect(
            "card_detail_page",
            card_id=card.card_id,
        )

    approved_by_name = request.POST.get(
        "approved_by_name",
        "",
    ).strip()

    uploaded_signature = request.FILES.get(
        "approval_signature"
    )

    assignment.approved_by_name = approved_by_name

    if uploaded_signature:
        allowed_types = {
            "image/png",
            "image/jpeg",
            "image/webp",
        }

        if uploaded_signature.content_type not in allowed_types:
            return redirect(
                "card_detail_page",
                card_id=card.card_id,
            )

        if uploaded_signature.size > 2 * 1024 * 1024:
            return redirect(
                "card_detail_page",
                card_id=card.card_id,
            )

        if assignment.approval_signature:
            assignment.approval_signature.delete(
                save=False
            )

        assignment.approval_signature = uploaded_signature

    assignment.save()

    return redirect(
        "card_detail_page",
        card_id=card.card_id,
    )


# ---------------------------------------------------------------------------
# Reports: export card + person details for a date range (PDF / Excel / CSV)
# ---------------------------------------------------------------------------

REPORT_COLUMNS = [
    "Issued Date",
    "Valid Until",
    "Person Name",
    "Person Type",
    "Contact",
    "Aadhaar",
    "Occupation",
    "Approved By",
]

_ALLOWED_REPORT_PERSON_TYPES = {
    "temporary",
    "permanent",
    "mes_contractor",
    "mes_labour",
    "mes_supervisor",
    "night",
}


def _parse_report_filters(request):
    """Read and validate the report filters from the request.

    Returns (start_date, end_date, person_type, error). Dates are
    ``datetime.date`` objects on success, ``None`` otherwise.
    """
    start_str = request.GET.get("start_date", "").strip()
    end_str = request.GET.get("end_date", "").strip()
    person_type = request.GET.get("person_type", "").strip()

    if person_type not in _ALLOWED_REPORT_PERSON_TYPES:
        person_type = ""

    if not start_str or not end_str:
        return None, None, person_type, None

    try:
        start_date = datetime.strptime(start_str, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_str, "%Y-%m-%d").date()
    except ValueError:
        return None, None, person_type, "Please provide valid start and end dates."

    if start_date > end_date:
        return None, None, person_type, "Start date cannot be after end date."

    return start_date, end_date, person_type, None


def _get_report_assignments(start_date, end_date, person_type):
    assignments = (
        CardAssignment.objects.select_related("person", "card")
        .filter(
            issued_at__date__gte=start_date,
            issued_at__date__lte=end_date,
        )
    )

    if person_type:
        assignments = assignments.filter(person__person_type=person_type)

    return assignments.order_by("issued_at", "card__card_id")


def _build_report_rows(assignments):
    rows = []

    for assignment in assignments:
        person = assignment.person

        issued = (
            timezone.localtime(assignment.issued_at).strftime("%Y-%m-%d %H:%M")
            if assignment.issued_at
            else "-"
        )
        valid_until = (
            timezone.localtime(assignment.valid_until).strftime("%Y-%m-%d %H:%M")
            if assignment.valid_until
            else "-"
        )

        rows.append(
            [
                issued,
                valid_until,
                person.name,
                _get_person_type_display(person.person_type),
                person.contact or "-",
                person.aadhaar_num or "-",
                person.occupation or "-",
                assignment.approved_by_name or "-",
            ]
        )

    return rows


def _report_filename(start_date, end_date, extension):
    return f"acs_report_{start_date:%Y%m%d}_{end_date:%Y%m%d}.{extension}"


def _report_csv_response(rows, start_date, end_date):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = (
        f'attachment; filename="{_report_filename(start_date, end_date, "csv")}"'
    )

    writer = csv.writer(response)
    writer.writerow(REPORT_COLUMNS)
    writer.writerows(rows)

    return response


def _report_xlsx_response(rows, start_date, end_date, person_type):
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Card Report"

    title = (
        f"Access Control Report  "
        f"({start_date:%d %b %Y} to {end_date:%d %b %Y})"
    )
    if person_type:
        title += f"  -  {_get_person_type_display(person_type)}"

    sheet.append([title])
    sheet.merge_cells(
        start_row=1,
        start_column=1,
        end_row=1,
        end_column=len(REPORT_COLUMNS),
    )
    title_cell = sheet.cell(row=1, column=1)
    title_cell.font = Font(bold=True, size=13)
    title_cell.alignment = Alignment(horizontal="center")

    header_fill = PatternFill("solid", fgColor="1F2937")
    header_font = Font(bold=True, color="FFFFFF")

    sheet.append(REPORT_COLUMNS)
    for col_idx in range(1, len(REPORT_COLUMNS) + 1):
        cell = sheet.cell(row=2, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    for row in rows:
        sheet.append(row)

    # Auto-size columns based on content width.
    for col_idx, column_name in enumerate(REPORT_COLUMNS, start=1):
        max_length = len(column_name)
        for row in rows:
            value = row[col_idx - 1]
            if value and len(value) > max_length:
                max_length = len(value)
        sheet.column_dimensions[get_column_letter(col_idx)].width = min(
            max_length + 2, 40
        )

    sheet.freeze_panes = "A3"

    response = HttpResponse(
        content_type=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        )
    )
    response["Content-Disposition"] = (
        f'attachment; filename="{_report_filename(start_date, end_date, "xlsx")}"'
    )
    workbook.save(response)

    return response


def _report_pdf_response(rows, start_date, end_date, person_type):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(A4),
        leftMargin=10 * mm,
        rightMargin=10 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm,
        title="Access Control Report",
    )

    styles = getSampleStyleSheet()
    elements = []

    title = f"Access Control Report ({start_date:%d %b %Y} to {end_date:%d %b %Y})"
    elements.append(Paragraph(title, styles["Title"]))

    subtitle = f"Person type: {_get_person_type_display(person_type) if person_type else 'All'}"
    subtitle += f"  |  Records: {len(rows)}"
    subtitle += f"  |  Generated: {timezone.localtime():%d %b %Y %H:%M}"
    elements.append(Paragraph(subtitle, styles["Normal"]))
    elements.append(Spacer(1, 6 * mm))

    cell_style = styles["BodyText"]
    cell_style.fontSize = 7
    cell_style.leading = 9

    header_cells = [Paragraph(f"<b>{col}</b>", cell_style) for col in REPORT_COLUMNS]
    table_data = [header_cells]
    for row in rows:
        table_data.append([Paragraph(str(value), cell_style) for value in row])

    table = Table(table_data, repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F2937")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#9AA4B2")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F1F5F9")]),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 3),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )

    if rows:
        elements.append(table)
    else:
        elements.append(
            Paragraph("No records found for the selected range.", styles["Normal"])
        )

    doc.build(elements)
    pdf = buffer.getvalue()
    buffer.close()

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f'inline; filename="{_report_filename(start_date, end_date, "pdf")}"'
    )
    response.write(pdf)

    return response


@never_cache
@login_required
@admin_required
def reports_page(request):
    start_date, end_date, person_type, error = _parse_report_filters(request)

    # Default the form to the last 30 days on first load.
    today = timezone.localdate()
    default_start = (today - timedelta(days=30)).strftime("%Y-%m-%d")
    default_end = today.strftime("%Y-%m-%d")

    export_format = request.GET.get("format", "").strip().lower()
    has_filters = bool(request.GET.get("start_date") or request.GET.get("end_date"))

    rows = None
    result_count = 0

    if start_date and end_date and not error:
        assignments = _get_report_assignments(start_date, end_date, person_type)
        rows = _build_report_rows(assignments)
        result_count = len(rows)

        if export_format == "csv":
            return _report_csv_response(rows, start_date, end_date)
        if export_format == "xlsx":
            return _report_xlsx_response(rows, start_date, end_date, person_type)
        if export_format == "pdf":
            return _report_pdf_response(rows, start_date, end_date, person_type)

    return render(
        request,
        "reports.html",
        {
            "columns": REPORT_COLUMNS,
            "rows": rows,
            "result_count": result_count,
            "error": error,
            "has_filters": has_filters,
            "person_type": person_type,
            "person_type_choices": Person.PERSON_TYPE_CHOICES,
            "start_date": request.GET.get("start_date", default_start),
            "end_date": request.GET.get("end_date", default_end),
            "is_demo": False,
        },
    )
