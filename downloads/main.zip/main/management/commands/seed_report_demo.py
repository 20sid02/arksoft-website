import random

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from main.models import (
    AccessLog,
    Card,
    CardAssignment,
    Person,
    PoliceVerification,
)

from .seed_load_test_data import (
    LOAD_PERSON_START_ID,
    LOAD_CARD_START_ID,
    LOAD_PERSON_END_ID,
    LOAD_CARD_END_ID,
    PERSON_TYPES,
    FIRST_NAMES,
    LAST_NAMES,
    OCCUPATIONS,
    SPONSOR_RANKS,
    SPONSOR_NAMES,
    SPONSOR_UNITS,
    generate_qr,
    remove_qr,
    resolve_card_type,
    get_or_create_demo_gates,
    get_or_create_demo_guard,
)


DEFAULT_COUNT = 50
DEFAULT_WEEKS = 5

APPROVING_OFFICERS = [
    "Maj R K Thakur",
    "Capt S P Negi",
    "Sub Maj A K Rana",
    "Lt V S Chauhan",
    "Maj D P Singh",
]


class Command(BaseCommand):
    help = (
        "Replace the bulk load-test data with a small, report-friendly "
        "set (default 50) of people/cards spread over several weeks so the "
        "date-range report shows a handful of cards per week."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--count",
            type=int,
            default=DEFAULT_COUNT,
            help="Number of people/cards to generate (default 50)",
        )
        parser.add_argument(
            "--weeks",
            type=int,
            default=DEFAULT_WEEKS,
            help="Number of weeks to spread issue dates across (default 5)",
        )
        parser.add_argument(
            "--keep-existing",
            action="store_true",
            help="Do not clear the existing load-test range first",
        )
        parser.add_argument(
            "--skip-qr",
            action="store_true",
            help="Skip QR generation for faster runs",
        )

    def _clear_load_test_data(self):
        self.stdout.write("Clearing existing load-test range data...")

        load_cards = Card.objects.filter(
            card_id__gte=LOAD_CARD_START_ID,
            card_id__lt=LOAD_CARD_END_ID,
        )
        load_people = Person.objects.filter(
            user_id__gte=LOAD_PERSON_START_ID,
            user_id__lt=LOAD_PERSON_END_ID,
        )

        load_card_ids = list(load_cards.values_list("card_id", flat=True))

        AccessLog.objects.filter(card_id__in=load_card_ids).delete()
        CardAssignment.objects.filter(card_id__in=load_card_ids).delete()
        PoliceVerification.objects.filter(person__in=load_people).delete()
        load_cards.delete()
        load_people.delete()

        for card_id in load_card_ids:
            remove_qr(card_id)

        self.stdout.write(
            f"Removed {len(load_card_ids)} old load-test cards/people."
        )

    @transaction.atomic
    def handle(self, *args, **options):
        count = options["count"]
        weeks = options["weeks"]
        keep_existing = options["keep_existing"]
        skip_qr = options["skip_qr"]

        if count <= 0:
            self.stdout.write(self.style.ERROR("Count must be > 0."))
            return
        if weeks <= 0:
            self.stdout.write(self.style.ERROR("Weeks must be > 0."))
            return

        if not keep_existing:
            self._clear_load_test_data()

        get_or_create_demo_gates()
        get_or_create_demo_guard()

        now = timezone.now()
        today = timezone.localdate()

        per_week = {}

        self.stdout.write(
            f"Generating {count} people/cards spread across {weeks} weeks..."
        )

        for index in range(count):
            user_id = LOAD_PERSON_START_ID + index
            card_id = LOAD_CARD_START_ID + index

            person_type = PERSON_TYPES[index % len(PERSON_TYPES)]

            occupations = OCCUPATIONS[person_type]
            occupation = occupations[
                (index // len(PERSON_TYPES)) % len(occupations)
            ]

            first_name = FIRST_NAMES[index % len(FIRST_NAMES)]
            last_name = LAST_NAMES[index % len(LAST_NAMES)]
            name = f"{first_name} {last_name}"

            aadhaar_num = f"{760000000000 + index:012d}"
            contact = f"9{700000000 + index * 137 % 299999999:09d}"[:10]

            # Police verification: temporary people have none; others get a
            # valid record so their card resolves to the proper colour.
            if person_type == "temporary":
                police_station = ""
                verification_number = ""
                issue_date = None
                police_valid_until = None
            else:
                police_station = f"Report Demo Police Station, Zone {index % 8}"
                verification_number = f"PV-DEMO-{user_id}"
                issue_date = today - timedelta(days=random.randint(20, 180))
                police_valid_until = today + timedelta(
                    days=random.randint(120, 700)
                )

            card_type = resolve_card_type(person_type, police_valid_until)

            person = Person.objects.create(
                user_id=user_id,
                name=name,
                contact=contact,
                aadhaar_num=aadhaar_num,
                occupation=occupation,
                identification_mark=f"Mole on left hand ({index + 1})"
                if index % 3 == 0
                else "",
                address=f"House {index + 1}, Demo Colony, Demo City",
                temporary_address=f"Qtr {index % 20}, Gate Area, Demo Cantt",
                person_type=person_type,
                sponsor_rank=random.choice(SPONSOR_RANKS),
                sponsor_name=random.choice(SPONSOR_NAMES),
                sponsor_unit=random.choice(SPONSOR_UNITS),
                security_deposit_amount=random.choice(
                    [500, 1000, 1500, 2000, 2500]
                ),
            )

            PoliceVerification.objects.create(
                person=person,
                police_station=police_station,
                verification_number=verification_number,
                issue_date=issue_date,
                valid_until=police_valid_until,
            )

            card = Card.objects.create(
                card_id=card_id,
                status="VA",
                card_type=card_type,
            )

            # Spread issue dates evenly across `weeks`, oldest first, with a
            # random day/time within each week so dates look natural.
            week_index = index * weeks // count  # 0 .. weeks-1
            weeks_ago = weeks - 1 - week_index
            issued_at = now - timedelta(
                days=weeks_ago * 7 + random.randint(0, 6),
                hours=random.randint(0, 10),
                minutes=random.randint(0, 59),
            )
            valid_until = issued_at + timedelta(days=random.randint(90, 365))

            assignment = CardAssignment.objects.create(
                person=person,
                card=card,
                valid_until=valid_until,
                active=True,
                approved_by_name=random.choice(APPROVING_OFFICERS),
            )

            # issued_at is auto_now_add, so override it after creation.
            CardAssignment.objects.filter(pk=assignment.pk).update(
                issued_at=issued_at
            )

            bucket = issued_at.date().isocalendar()[:2]
            per_week[bucket] = per_week.get(bucket, 0) + 1

            if not skip_qr:
                generate_qr(card_id)

        self.stdout.write(self.style.SUCCESS(f"Created {count} records."))
        self.stdout.write("Cards issued per (ISO year, week):")
        for bucket in sorted(per_week):
            self.stdout.write(f"  {bucket[0]}-W{bucket[1]:02d}: {per_week[bucket]}")
