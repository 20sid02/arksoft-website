import os
from decimal import Decimal, InvalidOperation
import random, re, base64
from datetime import datetime, timedelta

import qrcode
from django.db import transaction
from django.core.files.base import ContentFile
from django.conf import settings
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.cache import never_cache
from django.contrib.auth.decorators import login_required

from .card_type_service import resolve_card_type
from .models import AccessLog, Card, CardAssignment, GateDevice, GateInfo, Guard, Person, PoliceVerification
from .decorators import admin_api_required
from .card_service import create_card_logic

def _get_display_status(card, assignment):
    if card.status == "BL":
        return "BLACKLISTED"
    if card.status == "FL":
        return "FLAGGED"
    if card.status == "IV":
        return "INVALID"
    if not assignment:
        return "NO ASSIGNMENT"
    if not assignment.active:
        return "INACTIVE"
    if assignment.valid_until < timezone.now():
        return "EXPIRED"
    if card.status == "VA":
        return "ACTIVE"
    return "UNKNOWN"


def _resolve_valid_until(validity_option, custom_date):
    now = timezone.now()

    if validity_option == "24h":
        return now + timedelta(hours=24)
    if validity_option == "1w":
        return now + timedelta(weeks=1)
    if validity_option == "1m":
        return now + timedelta(days=30)
    if validity_option == "3m":
        return now + timedelta(days=90)
    if validity_option == "6m":
        return now + timedelta(days=180)
    if validity_option == "custom" and custom_date:
        valid_until = datetime.strptime(custom_date, "%Y-%m-%d")
        valid_until = valid_until.replace(hour=23, minute=59, second=59)
        return timezone.make_aware(valid_until)
    return None


def generate_card_id():
    while True:
        card_id = random.randint(10000000, 99999999)
        if not Card.objects.filter(card_id=card_id).exists():
            return card_id


def generate_user_id():
    while True:
        user_id = random.randint(100000, 999999)
        if not Person.objects.filter(user_id=user_id).exists():
            return user_id
        
def create_denied_log(card, gate, guard):
    return AccessLog.objects.create(
        card=card,
        gate=gate,
        access_type="DENIED",
        scanned_by=guard,
    )        

@login_required
@csrf_exempt
def scan_card(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST only"})

    card_id = request.POST.get("card_id")
    gate_id = request.POST.get("gate_id")

    if not request.user.is_authenticated:
        return JsonResponse({
            "status": "denied",
            "reason": "Authentication required",
        })

    if not card_id:
        return JsonResponse({
            "status": "denied",
            "reason": "Card ID is required",
        })

    if not gate_id:
        return JsonResponse({
            "status": "denied",
            "reason": "Gate ID is required",
        })

    try:
        guard = request.user.guard_profile
    except Guard.DoesNotExist:
        return JsonResponse({
            "status": "denied",
            "reason": "No guard profile found",
        })

    if not guard.approved or not guard.active:
        return JsonResponse({
            "status": "denied",
            "reason": "Guard is not approved or inactive",
        })

    try:
        gate = GateDevice.objects.get(gate_id=gate_id)
    except GateDevice.DoesNotExist:
        return JsonResponse({
            "status": "denied",
            "reason": "Invalid Gate",
        })

    if not gate.status:
        return JsonResponse({
            "status": "denied",
            "reason": "Gate is inactive",
        })

    try:
        card = Card.objects.get(card_id=card_id)
    except Card.DoesNotExist:
        return JsonResponse({
            "status": "denied",
            "reason": "Card not found",
        })

    assignment = (
        CardAssignment.objects.filter(
            card=card,
            active=True,
        )
        .select_related("person")
        .order_by("-issued_at")
        .first()
    )

    person_name = (
        assignment.person.name
        if assignment and assignment.person
        else "Unknown"
    )

    # Prevent duplicate rapid scans for the same card.
    last_log = (
        AccessLog.objects
        .filter(card=card)
        .order_by("-timestamp")
        .first()
    )

    if last_log and timezone.now() - last_log.timestamp < timedelta(seconds=3):
        return JsonResponse({
            "status": "ignored",
            "reason": "Too Fast",
            "person": person_name,
            "card_id": card.card_id,
        })

    # ---------------------------------------------------------
    # Security/status denial checks
    # ---------------------------------------------------------

    if card.status == "BL":
        create_denied_log(card, gate, guard)

        return JsonResponse({
            "status": "denied",
            "reason": "Blacklisted",
            "card_id": card.card_id,
            "person": person_name,
            "alert": True,
            "alert_type": "blacklisted",
            "message": "Blacklisted Card Scanned",
        })

    if card.status == "FL":
        create_denied_log(card, gate, guard)

        return JsonResponse({
            "status": "flagged",
            "reason": "Card is flagged",
            "card_id": card.card_id,
            "person": person_name,
            "can_unflag": True,
            "alert": True,
            "alert_type": "flagged",
            "message": "Flagged Card Scanned",
        })

    if card.status == "IV" or card.is_hidden:
        create_denied_log(card, gate, guard)

        return JsonResponse({
            "status": "denied",
            "reason": "Invalid Card",
            "card_id": card.card_id,
            "person": person_name,
        })

    if card.status != "VA":
        create_denied_log(card, gate, guard)

        return JsonResponse({
            "status": "denied",
            "reason": "Invalid Card Status",
            "card_id": card.card_id,
            "person": person_name,
        })

    if not assignment:
        create_denied_log(card, gate, guard)

        return JsonResponse({
            "status": "denied",
            "reason": "No Active Assignment",
            "person": "Unknown",
            "card_id": card.card_id,
        })

    if assignment.valid_until < timezone.now():
        create_denied_log(card, gate, guard)

        return JsonResponse({
            "status": "denied",
            "reason": "Validity Expired",
            "person": person_name,
            "card_id": card.card_id,
        })

    # ---------------------------------------------------------
    # Allowed IN / OUT logic
    # ---------------------------------------------------------

    if not last_log or last_log.access_type in ["OUT", "DENIED"]:
        access_type = "IN"
    else:
        access_type = "OUT"

    AccessLog.objects.create(
        card=card,
        gate=gate,
        access_type=access_type,
        timestamp=timezone.now(),
        scanned_by=guard,
    )

    return JsonResponse({
        "status": "allowed",
        "access_type": access_type,
        "person": person_name,
        "card_id": card.card_id,
    })

def _parse_date(value):
    if not value:
        return None

    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None


def _resolve_card_type(person_type, police_valid_until):
    today = timezone.localdate()

    police_valid = police_valid_until and police_valid_until >= today

    if not police_valid:
        return "white"

    if person_type == "mes_labour":
        return "pink"

    if person_type == "mes_contractor":
        return "sky_blue"

    return "yellow"

@never_cache
@login_required
@admin_api_required
@csrf_exempt
@transaction.atomic
def create_card(request):
    if request.method != "POST":
        return JsonResponse(
            {
                "error": "POST only",
            },
            status=405,
        )

    # ---------------------------------------------------------
    # Basic person details
    # ---------------------------------------------------------

    name = request.POST.get("name", "").strip()
    contact = request.POST.get("contact", "").strip()
    aadhaar = request.POST.get("aadhaar", "").strip()
    occupation = request.POST.get("occupation", "").strip()

    identification_mark = request.POST.get(
        "identification_mark",
        "",
    ).strip()

    address = request.POST.get(
        "address",
        "",
    ).strip()

    # telephone_number = request.POST.get(
    #     "telephone_number",
    #     "",
    # ).strip()

    # quarter_number = request.POST.get(
    #     "quarter_number",
    #     "",
    # ).strip()

    # sector = request.POST.get(
    #     "sector",
    #     "",
    # ).strip()

    temporary_address = request.POST.get(
        "temporary_address",
        "",
    ).strip()

    person_type = request.POST.get(
        "person_type",
        "",
    ).strip()

    # ---------------------------------------------------------
    # Sponsor and deposit
    # ---------------------------------------------------------

    sponsor_rank = request.POST.get(
        "sponsor_rank",
        "",
    ).strip()

    sponsor_name = request.POST.get(
        "sponsor_name",
        "",
    ).strip()

    sponsor_unit = request.POST.get(
        "sponsor_unit",
        "",
    ).strip()

    security_deposit_raw = request.POST.get(
        "security_deposit_amount",
        "",
    ).strip()

    # ---------------------------------------------------------
    # Card validity
    # ---------------------------------------------------------

    validity_option = request.POST.get(
        "validity_option",
        "",
    ).strip()

    custom_date = request.POST.get(
        "valid_until",
        "",
    ).strip()

    # ---------------------------------------------------------
    # Existing-person and photo data
    # ---------------------------------------------------------

    existing_person_id = request.POST.get(
        "existing_person_id",
        "",
    ).strip()

    photo_data = request.POST.get(
        "photo_data",
        "",
    ).strip()

    # ---------------------------------------------------------
    # Police verification
    # ---------------------------------------------------------

    police_station = request.POST.get(
        "police_station",
        "",
    ).strip()

    verification_number = request.POST.get(
        "verification_number",
        "",
    ).strip()

    police_issue_raw = request.POST.get(
        "police_issue_date",
        "",
    ).strip()

    police_valid_until_raw = request.POST.get(
        "police_valid_until",
        "",
    ).strip()

    # ---------------------------------------------------------
    # Approval signature
    # ---------------------------------------------------------

    approved_by_name = request.POST.get(
        "approved_by_name",
        "",
    ).strip()

    approval_signature = request.FILES.get(
        "approval_signature"
    )

    # ---------------------------------------------------------
    # Validate basic input
    # ---------------------------------------------------------

    if not re.fullmatch(r"\d{12}", aadhaar):
        return JsonResponse(
            {
                "error": "Aadhaar must be exactly 12 digits",
            },
            status=400,
        )

    valid_until = _resolve_valid_until(
        validity_option,
        custom_date,
    )

    if not valid_until:
        return JsonResponse(
            {
                "error": "Invalid card validity option",
            },
            status=400,
        )

    allowed_person_types = {
        "temporary",
        "permanent",
        "mes_labour",
        "mes_contractor",
        "mes_supervisor",
        "night",
    }

    if person_type and person_type not in allowed_person_types:
        return JsonResponse(
            {
                "error": "Invalid person classification",
            },
            status=400,
        )

    if name and not re.fullmatch(r"[A-Za-z .]+", name):
        return JsonResponse(
            {
                "error": (
                    "Name can only contain letters, "
                    "spaces, and dots"
                ),
            },
            status=400,
        )

    if contact and not re.fullmatch(r"\d{10}", contact):
        return JsonResponse(
            {
                "error": "Contact must be exactly 10 digits",
            },
            status=400,
        )

    # ---------------------------------------------------------
    # Validate security deposit
    # ---------------------------------------------------------

    security_deposit = None

    if security_deposit_raw:
        try:
            security_deposit = Decimal(
                security_deposit_raw
            )

            if security_deposit < 0:
                raise InvalidOperation

        except (InvalidOperation, ValueError):
            return JsonResponse(
                {
                    "error": (
                        "Security deposit must be a valid "
                        "non-negative amount"
                    ),
                },
                status=400,
            )

    # ---------------------------------------------------------
    # Parse and validate police dates before DB changes
    # ---------------------------------------------------------

    police_issue_date = _parse_date(
        police_issue_raw
    )

    police_valid_until = _parse_date(
        police_valid_until_raw
    )

    if police_issue_raw and police_issue_date is None:
        return JsonResponse(
            {
                "error": "Invalid police issue date",
            },
            status=400,
        )

    if (
        police_valid_until_raw
        and police_valid_until is None
    ):
        return JsonResponse(
            {
                "error": (
                    "Invalid police verification expiry date"
                ),
            },
            status=400,
        )

    # ---------------------------------------------------------
    # Validate signature before creating anything
    # ---------------------------------------------------------

    if approval_signature:
        allowed_signature_types = {
            "image/png",
            "image/jpeg",
            "image/webp",
        }

        if (
            approval_signature.content_type
            not in allowed_signature_types
        ):
            return JsonResponse(
                {
                    "error": (
                        "Signature must be a PNG, JPEG, "
                        "or WebP image"
                    ),
                },
                status=400,
            )

        maximum_signature_size = 2 * 1024 * 1024

        if approval_signature.size > maximum_signature_size:
            return JsonResponse(
                {
                    "error": (
                        "Signature image must be smaller "
                        "than 2 MB"
                    ),
                },
                status=400,
            )

    # ---------------------------------------------------------
    # Decode captured photo before database changes
    # ---------------------------------------------------------

    prepared_photo = None

    if photo_data:
        try:
            if ";base64," not in photo_data:
                raise ValueError(
                    "Invalid captured-photo format"
                )

            format_part, encoded_image = photo_data.split(
                ";base64,",
                1,
            )

            extension = (
                format_part
                .split("/")[-1]
                .lower()
            )

            if extension == "jpeg":
                extension = "jpg"

            if extension not in {
                "jpg",
                "png",
                "webp",
            }:
                raise ValueError(
                    "Unsupported captured-photo format"
                )

            decoded_image = base64.b64decode(
                encoded_image
            )

            prepared_photo = {
                "content": decoded_image,
                "extension": extension,
            }

        except Exception:
            return JsonResponse(
                {
                    "error": (
                        "Captured photo could not be processed"
                    ),
                },
                status=400,
            )

    # ---------------------------------------------------------
    # Find or create person
    # ---------------------------------------------------------

    person = (
        Person.objects
        .select_for_update()
        .filter(aadhaar_num=aadhaar)
        .first()
    )

    person_reused = person is not None

    if person:
        if (
            existing_person_id
            and str(person.user_id) != existing_person_id
        ):
            return JsonResponse(
                {
                    "error": (
                        "The selected existing person does "
                        "not match the entered Aadhaar number"
                    ),
                },
                status=400,
            )

        active_visible_assignment = (
            CardAssignment.objects
            .filter(
                person=person,
                active=True,
                card__is_hidden=False,
            )
            .select_related("card")
            .order_by("-issued_at")
            .first()
        )

        if active_visible_assignment:
            return JsonResponse(
                {
                    "error": (
                        "This person already has active card "
                        f"{active_visible_assignment.card.card_id}. "
                        "Disable that card before issuing "
                        "another one."
                    ),
                },
                status=400,
            )

        # Blank values preserve existing data.
        person_updates = {
            "name": name,
            "contact": contact,
            "occupation": occupation,
            "identification_mark": (
                identification_mark
            ),
            "address": address,
            # "telephone_number": telephone_number,
            # "quarter_number": quarter_number,
            # "sector": sector,
            "temporary_address": temporary_address,
            "person_type": person_type,
            "sponsor_rank": sponsor_rank,
            "sponsor_name": sponsor_name,
            "sponsor_unit": sponsor_unit,
        }

        for field_name, field_value in person_updates.items():
            if field_value:
                setattr(
                    person,
                    field_name,
                    field_value,
                )

        if security_deposit is not None:
            person.security_deposit_amount = (
                security_deposit
            )

        person.is_hidden = False
        person.hidden_at = None
        person.save()

    else:
        if not name:
            return JsonResponse(
                {
                    "error": (
                        "Name is required for a new person"
                    ),
                },
                status=400,
            )

        if not contact:
            return JsonResponse(
                {
                    "error": (
                        "Contact is required for a new person"
                    ),
                },
                status=400,
            )

        if not occupation:
            return JsonResponse(
                {
                    "error": (
                        "Occupation is required for a new person"
                    ),
                },
                status=400,
            )

        if not person_type:
            person_type = "temporary"

        person = Person.objects.create(
            user_id=generate_user_id(),
            name=name,
            contact=contact,
            aadhaar_num=aadhaar,
            occupation=occupation,
            identification_mark=identification_mark,
            address=address,
            # telephone_number=telephone_number,
            # quarter_number=quarter_number,
            # sector=sector,
            temporary_address=temporary_address,
            person_type=person_type,
            sponsor_rank=sponsor_rank,
            sponsor_name=sponsor_name,
            sponsor_unit=sponsor_unit,
            security_deposit_amount=(
                security_deposit
                if security_deposit is not None
                else Decimal("0")
            ),
            is_hidden=False,
            hidden_at=None,
        )

    # ---------------------------------------------------------
    # Save or replace captured photo
    # ---------------------------------------------------------

    if prepared_photo:
        image_content = ContentFile(
            prepared_photo["content"],
            name=(
                f"person_{person.user_id}."
                f"{prepared_photo['extension']}"
            ),
        )

        if person.photo:
            person.photo.delete(save=False)

        person.photo.save(
            image_content.name,
            image_content,
            save=True,
        )

    # ---------------------------------------------------------
    # Save police verification
    # ---------------------------------------------------------

    police_fields_supplied = any(
        [
            police_station,
            verification_number,
            police_issue_raw,
            police_valid_until_raw,
        ]
    )

    if police_fields_supplied:
        verification, _ = (
            PoliceVerification.objects.get_or_create(
                person=person
            )
        )

        if police_station:
            verification.police_station = police_station

        if verification_number:
            verification.verification_number = verification_number

        if police_issue_raw:
            verification.issue_date = (
                police_issue_date
            )

        if police_valid_until_raw:
            verification.valid_until = (
                police_valid_until
            )

        verification.save()

    # ---------------------------------------------------------
    # Invalidate any remaining old active assignments
    # ---------------------------------------------------------

    old_assignments = (
        CardAssignment.objects
        .filter(
            person=person,
            active=True,
        )
        .select_related("card")
    )

    previous_card_ids = []

    for old_assignment in old_assignments:
        previous_card_ids.append(
            old_assignment.card.card_id
        )

        old_assignment.active = False
        old_assignment.save(
            update_fields=["active"]
        )

        old_card = old_assignment.card

        if old_card.status != "BL":
            old_card.status = "IV"

        old_card.is_hidden = True
        old_card.hidden_at = timezone.now()

        old_card.save(
            update_fields=[
                "status",
                "is_hidden",
                "hidden_at",
            ]
        )

    # ---------------------------------------------------------
    # Create new card and assignment
    # ---------------------------------------------------------

    card_id = generate_card_id()
    card_type = resolve_card_type(person)

    card = Card.objects.create(
        card_id=card_id,
        status="VA",
        card_type=card_type,
        is_hidden=False,
        hidden_at=None,
    )

    assignment = CardAssignment.objects.create(
        person=person,
        card=card,
        valid_until=valid_until,
        active=True,
        approved_by_name=approved_by_name,
        approval_signature=approval_signature,
    )

    # ---------------------------------------------------------
    # Generate QR code
    # ---------------------------------------------------------

    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=1,
    )

    qr.add_data(str(card_id))
    qr.make(fit=True)

    qr_image = qr.make_image(
        fill_color="black",
        back_color="white",
    )

    qr_folder = os.path.join(
        settings.MEDIA_ROOT,
        "qr_codes",
    )

    os.makedirs(
        qr_folder,
        exist_ok=True,
    )

    qr_path = os.path.join(
        qr_folder,
        f"{card_id}.png",
    )

    qr_image.save(qr_path)

    return JsonResponse(
        {
            "status": (
                "card_reissued"
                if person_reused
                else "card_created"
            ),
            "person_reused": person_reused,
            "user_id": person.user_id,
            "card_id": card.card_id,
            "card_type": card.card_type,
            "card_type_display": (
                card.get_card_type_display()
            ),
            "previous_card_ids": previous_card_ids,
            "approved_by_name": (
                assignment.approved_by_name
            ),
            "signature_saved": bool(
                assignment.approval_signature
            ),
        }
    )

@never_cache

def gates_api(request):

    if request.method != "GET":

        return JsonResponse({"status": "error", "reason": "GET only"})

    if not request.user.is_authenticated:

        return JsonResponse({

            "status": "denied",

            "reason": "Authentication required"

        })

    gates = GateDevice.objects.prefetch_related("gateinfo_set").order_by("gate_id")

    data = []

    for gate in gates:

        gate_info = next(iter(gate.gateinfo_set.all()), None)

        data.append({

            "id": gate.gate_id,

            "name": gate_info.name if gate_info else f"Gate {gate.gate_id}",

        })

    return JsonResponse({

        "status": "ok",

        "gates": data,

    })

@never_cache
@login_required
@admin_api_required
@csrf_exempt
def logs_api(request):
    if request.method != "GET":
        return JsonResponse({"status": "error", "reason": "GET only"})

    if not request.user.is_authenticated:
        return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    logs = (
        AccessLog.objects.select_related("card", "gate", "scanned_by")
        .prefetch_related("gate__gateinfo_set")
        .order_by("-timestamp")[:100]
    )

    data = []
    for log in logs:
        assignment = (
            log.card.cardassignment_set.select_related("person")
            .order_by("-issued_at")
            .first()
        )
        person_name = assignment.person.name if assignment and assignment.person else "Unknown"
        gate_info = log.gate.gateinfo_set.first()
        gate_name = gate_info.name if gate_info else f"Gate {log.gate.gate_id}"

        data.append(
            {
                "card_id": log.card.card_id,
                "person": person_name,
                "gate_name": gate_name,
                "access_type": log.access_type,
                "timestamp": log.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "scanned_by": log.scanned_by.full_name if log.scanned_by else "Unknown",
            }
        )

    return JsonResponse({"status": "ok", "logs": data})

@never_cache
@login_required
@admin_api_required
def lookup_person_by_aadhaar(request):
    if request.method != "GET":
        return JsonResponse({
            "status": "error",
            "reason": "GET only",
        })

    aadhaar = request.GET.get("aadhaar", "").strip()

    if not re.fullmatch(r"\d{12}", aadhaar):
        return JsonResponse({
            "status": "error",
            "reason": "Aadhaar must be exactly 12 digits",
        })

    person = Person.objects.filter(
        aadhaar_num=aadhaar,
    ).first()

    if not person:
        return JsonResponse({
            "status": "not_found",
            "message": "No existing person found",
        })

    police_verification = getattr(
        person,
        "police_verification",
        None,
    )

    latest_assignment = (
        CardAssignment.objects.filter(person=person)
        .select_related("card")
        .order_by("-issued_at")
        .first()
    )

    return JsonResponse({
        "status": "found",
        "person": {
            "user_id": person.user_id,
            "name": person.name,
            "contact": person.contact,
            "aadhaar_num": person.aadhaar_num,
            "occupation": person.occupation,
            "identification_mark": person.identification_mark,
            "address": person.address,
            # "telephone_number": person.telephone_number,
            # "quarter_number": person.quarter_number,
            # "sector": person.sector,
            "temporary_address": person.temporary_address,
            "person_type": person.person_type,
            "sponsor_rank": person.sponsor_rank,
            "sponsor_name": person.sponsor_name,
            "sponsor_unit": person.sponsor_unit,
            "security_deposit_amount": str(
                person.security_deposit_amount
            ),
            "is_hidden": person.is_hidden,
            "photo_url": (
                person.photo.url
                if person.photo
                else None
            ),
        },
        "police_verification": {
            "police_station": (
                police_verification.police_station
                if police_verification
                else ""
            ),
            "verification_number": (
                police_verification.verification_number
                if police_verification
                else ""
            ),
            "issue_date": (
                police_verification.issue_date.isoformat()
                if police_verification
                and police_verification.issue_date
                else None
            ),
            "valid_until": (
                police_verification.valid_until.isoformat()
                if police_verification
                and police_verification.valid_until
                else None
            ),
            "is_valid": (
                police_verification.is_valid()
                if police_verification
                else False
            ),
        },
        "latest_card": {
            "card_id": latest_assignment.card.card_id,
            "status": latest_assignment.card.status,
            "card_type": latest_assignment.card.card_type,
            "assignment_active": latest_assignment.active,
        } if latest_assignment else None,
    })

@never_cache
@login_required
@admin_api_required
def people_api(request):
    if request.method != "GET":
        return JsonResponse({"status": "error", "reason": "GET only"})

    # if not request.user.is_authenticated:
    #     return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    include_hidden = (
        request.GET.get("include_hidden") == "1"
    )

    people = Person.objects.all()

    if not include_hidden:
        people = people.filter(is_hidden=False)

    people = people.order_by("-user_id")
    
    data = []

    for person in people:
        latest_assignment = (
            person.cardassignment_set.select_related("card")
            .order_by("-issued_at")
            .first()
        )

        card_id = None
        valid_until = None
        assignment_active = False
        card_status = None
        display_status = "NO CARD"

        if latest_assignment:
            card = latest_assignment.card
            card_id = card.card_id
            valid_until = latest_assignment.valid_until.strftime("%Y-%m-%d %H:%M:%S")
            assignment_active = latest_assignment.active
            card_status = card.status
            display_status = _get_display_status(card, latest_assignment)

        data.append(
            {
                "user_id": person.user_id,
                "name": person.name,
                "contact": person.contact,
                "aadhaar_num": person.aadhaar_num,
                "card_id": card_id,
                "card_status": card_status,
                "valid_until": valid_until,
                "assignment_active": assignment_active,
                "display_status": display_status,
            }
        )

    return JsonResponse({"status": "ok", "people": data})


@csrf_exempt
def guard_login(request):
    if request.method != "POST":
        return JsonResponse({"status": "error", "reason": "POST only"})

    username = request.POST.get("username")
    password = request.POST.get("password")
    user = authenticate(request, username=username, password=password)

    if user is None:
        return JsonResponse({"status": "denied", "reason": "Invalid credentials"})

    try:
        guard = user.guard_profile
    except Guard.DoesNotExist:
        return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    if not guard.active:
        return JsonResponse({"status": "denied", "reason": "Guard inactive"})

    if not guard.approved:
        return JsonResponse({"status": "denied", "reason": "Guard not approved"})

    login(request, user)

    return JsonResponse(
        {
            "status": "allowed",
            "username": user.username,
            "full_name": guard.full_name,
            "role": guard.role,
        }
    )

@never_cache
@login_required
@admin_api_required
@csrf_exempt
def create_guard(request):
    if request.method != "POST":
        return JsonResponse({"status": "error", "reason": "POST only"})

    username = request.POST.get("username")
    password = request.POST.get("password")
    full_name = request.POST.get("full_name")
    employee_id = request.POST.get("employee_id")
    contact = request.POST.get("contact")
    role = request.POST.get("role", "guard")
    approved = request.POST.get("approved", "false").lower() == "true"

    if not all([username, password, full_name, employee_id]):
        return JsonResponse({"status": "error", "reason": "Missing required fields"})

    if User.objects.filter(username=username).exists():
        return JsonResponse({"status": "error", "reason": "Username already exists"})

    if Guard.objects.filter(employee_id=employee_id).exists():
        return JsonResponse({"status": "error", "reason": "Employee ID already exists"})

    user = User.objects.create_user(username=username, password=password)

    guard = Guard.objects.create(
        user=user,
        full_name=full_name,
        employee_id=employee_id,
        contact=contact or "",
        role=role,
        approved=approved,
        active=True,
    )

    return JsonResponse(
        {
            "status": "created",
            "guard_id": guard.id,
            "username": user.username,
            "role": guard.role,
        }
    )

@never_cache
@login_required
@admin_api_required
def guards_api(request):
    if request.method != "GET":
        return JsonResponse({"status": "error", "reason": "GET only"})

    # if not request.user.is_authenticated:
    #     return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    guards = Guard.objects.select_related("user").order_by("-created_at")
    data = []

    for item in guards:
        data.append(
            {
                "id": item.id,
                "full_name": item.full_name,
                "username": item.user.username,
                "employee_id": item.employee_id,
                "contact": item.contact,
                "role": item.role,
                "approved": item.approved,
                "active": item.active,
                "created_at": item.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            }
        )

    return JsonResponse({"status": "ok", "guards": data})

@never_cache
@login_required
@admin_api_required
def card_detail_api(request, card_id):
    if request.method != "GET":
        return JsonResponse({"status": "error", "reason": "GET only"})

    # if not request.user.is_authenticated:
    #     return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    try:
        card = Card.objects.get(card_id=card_id)
    except Card.DoesNotExist:
        return JsonResponse({"status": "error", "reason": "Card not found"})

    assignment = (
        CardAssignment.objects.filter(card=card)
        .select_related("person")
        .order_by("-issued_at")
        .first()
    )

    person_data = None
    if assignment and assignment.person:
        person_data = {
            "user_id": assignment.person.user_id,
            "name": assignment.person.name,
            "contact": assignment.person.contact,
            "aadhaar_num": assignment.person.aadhaar_num,
        }

    return JsonResponse(
        {
            "status": "ok",
            "card": {
                "card_id": card.card_id,
                "card_status": card.status,
                "display_status": _get_display_status(card, assignment),
                "person": person_data,
                "valid_until": (
                    assignment.valid_until.strftime("%Y-%m-%d %H:%M:%S")
                    if assignment
                    else None
                ),
                "assignment_active": assignment.active if assignment else False,
            },
        }
    )

@never_cache
@login_required
@admin_api_required
def renew_card_api(request, card_id):
    if request.method != "POST":
        return JsonResponse({"status": "error", "reason": "POST only"})

    # if not request.user.is_authenticated:
    #     return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    try:
        card = Card.objects.get(card_id=card_id)
    except Card.DoesNotExist:
        return JsonResponse({"status": "error", "reason": "Card not found"})

    assignment = CardAssignment.objects.filter(card=card).order_by("-issued_at").first()
    if not assignment:
        return JsonResponse({"status": "error", "reason": "No assignment found"})

    valid_until = _resolve_valid_until(
        request.POST.get("validity_option"),
        request.POST.get("valid_until"),
    )
    if not valid_until:
        return JsonResponse({"status": "error", "reason": "Invalid validity option"})

    assignment.valid_until = valid_until
    assignment.active = True
    assignment.save()

    if card.status in ["IV", "VA"]:
        card.status = "VA"
        card.save()

    return JsonResponse(
        {
            "status": "ok",
            "message": "Card renewed successfully",
            "valid_until": valid_until.strftime("%Y-%m-%d %H:%M:%S"),
        }
    )

@never_cache
@login_required
@admin_api_required
def blacklist_card_api(request, card_id):
    if request.method != "POST":
        return JsonResponse({"status": "error", "reason": "POST only"})

    # if not request.user.is_authenticated:
    #     return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    try:
        card = Card.objects.get(card_id=card_id)
    except Card.DoesNotExist:
        return JsonResponse({"status": "error", "reason": "Card not found"})

    card.status = "BL"
    card.save()
    return JsonResponse({"status": "ok", "message": "Card blacklisted"})

@never_cache
@login_required
@admin_api_required
def unblacklist_card_api(request, card_id):
    if request.method != "POST":
        return JsonResponse({"status": "error", "reason": "POST only"})

    # if not request.user.is_authenticated:
    #     return JsonResponse({"status": "denied", "reason": "Authentication required"})

    # try:
    #     guard = request.user.guard_profile
    # except Guard.DoesNotExist:
    #     return JsonResponse({"status": "denied", "reason": "No guard profile found"})

    # if guard.role != "admin":
    #     return JsonResponse({"status": "denied", "reason": "Admin only"})

    try:
        card = Card.objects.get(card_id=card_id)
    except Card.DoesNotExist:
        return JsonResponse({"status": "error", "reason": "Card not found"})

    card.status = "VA"
    card.save()
    return JsonResponse({"status": "ok", "message": "Card unblacklisted"})






@csrf_exempt

def unflag_card_api(request, card_id):

    if request.method != "POST":

        return JsonResponse({

            "status": "error",

            "reason": "POST only"

        })

    if not request.user.is_authenticated:

        return JsonResponse({

            "status": "denied",

            "reason": "Authentication required"

        })

    # allow admin or approved guard

    try:

        guard = request.user.guard_profile

    except Exception:

        return JsonResponse({

            "status": "denied",

            "reason": "Guard profile not found"

        })

    if not guard.active or not guard.approved:

        return JsonResponse({

            "status": "denied",

            "reason": "Guard not approved"

        })

    card = get_object_or_404(Card, card_id=card_id)

    if card.status != "FL":

        return JsonResponse({

            "status": "ok",

            "message": "Card is not flagged"

        })

    card.status = "VA"

    card.save(update_fields=["status"])

    return JsonResponse({

        "status": "ok",

        "message": "Card unflagged successfully",

        "card_id": card.card_id

    })

