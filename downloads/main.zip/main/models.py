from django.db import models
from django.contrib.auth.models import User


class Person(models.Model):
    PERSON_TYPE_CHOICES = [
        ("temporary", "Temporary"),
        ("permanent", "Permanent"),
        ("mes_labour", "MES Labour"),
        ("mes_contractor", "MES Contractor"),
        ("mes_supervisor", "MES Supervisor"),
        ("night", "Night Pass"),
    ]

    user_id = models.BigIntegerField(primary_key=True)
    name = models.CharField(max_length=64)

    contact = models.CharField(max_length=15)
    aadhaar_num = models.CharField(max_length=12, unique=True, db_index=True)

    occupation = models.CharField(max_length=100, default="Occupation")

    identification_mark = models.CharField(max_length=200, blank=True)
    address = models.TextField(blank=True)

    temporary_address = models.TextField(blank=True)

    person_type = models.CharField(
        max_length=30,
        choices=PERSON_TYPE_CHOICES,
        default="temporary",
    )

    sponsor_rank = models.CharField(max_length=50, blank=True)
    sponsor_name = models.CharField(max_length=100, blank=True)
    sponsor_unit = models.CharField(max_length=100, blank=True)

    security_deposit_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    photo = models.ImageField(
        upload_to="person_photos/",
        null=True,
        blank=True,
    )
    is_hidden = models.BooleanField(default=False)

    hidden_at = models.DateTimeField(
        null=True,
        blank=True,
    )
    
    def __str__(self):
        return self.name

class Card(models.Model):
    STATUS_TYPES = [
        ("VA", "Valid"),
        ("IV", "Invalid"),
        ("BL", "Blacklisted"),
        ("FL", "Flagged"),
    ]

    CARD_TYPE_CHOICES = [
        ("yellow", "Permanent"),
        ("white", "Temporary"),
        ("pink", "MES"),
        ("sky_blue", "MES Contractor"),
        ("night", "Night Pass"),
    ]

    card_id = models.BigIntegerField(primary_key=True)

    status = models.CharField(
        max_length=2,
        choices=STATUS_TYPES,
        default="VA",
    )

    card_type = models.CharField(
        max_length=20,
        choices=CARD_TYPE_CHOICES,
        default="white",
    )

    is_hidden = models.BooleanField(default=False)
    hidden_at = models.DateTimeField(null=True, blank=True)


    def __str__(self):
        return str(self.card_id)


class CardAssignment(models.Model):

    person = models.ForeignKey(
        Person,
        on_delete=models.CASCADE
    )

    card = models.ForeignKey(
        Card,
        on_delete=models.CASCADE
    )

    approval_signature = models.ImageField(
        upload_to="approval_signatures/",
        null=True,
        blank=True,
    )
    
    approved_by_name = models.CharField(
        max_length=100,
        blank=True,
    )

    issued_at = models.DateTimeField(auto_now_add=True)

    valid_until = models.DateTimeField()

    active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.person} -> {self.card}"

class GateDevice(models.Model):

    gate_id = models.IntegerField(primary_key=True)

    status = models.BooleanField(default=True)

    def __str__(self):
        return f"Gate {self.gate_id}"


class GateInfo(models.Model):

    gate = models.ForeignKey(
        GateDevice,
        on_delete=models.CASCADE
    )

    name = models.CharField(max_length=32)

    notes = models.CharField(max_length=64)

    def __str__(self):
	    return f"{self.gate_id} -> {self.name}"
    
class Guard(models.Model):
    ROLE_CHOICES = [
    ("admin", "Admin"),
    ("guard", "Guard"),
    ("demo", "Demo"),
]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="guard_profile")
    full_name = models.CharField(max_length=100)
    employee_id = models.CharField(max_length=30, unique=True)
    contact = models.CharField(max_length=15, blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="guard")
    approved = models.BooleanField(default=False)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.full_name}"

class AccessLog(models.Model):

    ENTRY_EXIT_TYPES = [
        ("IN", "Entry"),
        ("OUT", "Exit"),
        ("DENIED", "Denied"),
    ]

    card = models.ForeignKey(
        Card,
        on_delete=models.PROTECT
    )

    gate = models.ForeignKey(
        GateDevice,
        on_delete=models.PROTECT
    )

    access_type = models.CharField(
        max_length=6,
        choices=ENTRY_EXIT_TYPES
    )

    scanned_by = models.ForeignKey(Guard, on_delete=models.PROTECT, null=True, blank=True)

    purpose = models.CharField(
        max_length=64,
        default="general"
    )

    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.access_type} -> {self.card} -> {self.gate_id}"


class PoliceVerification(models.Model):
    person = models.OneToOneField(
        Person,
        on_delete=models.CASCADE,
        related_name="police_verification",
    )

    police_station = models.TextField(blank=True)
    verification_number = models.CharField(max_length=100, blank=True)
    issue_date = models.DateField(null=True, blank=True)
    valid_until = models.DateField(null=True, blank=True)

    def is_valid(self):
        if not self.valid_until:
            return False

        from django.utils import timezone
        return self.valid_until >= timezone.localdate()

    def __str__(self):
        return f"Police Verification - {self.person.name}"